package stickmanTest.levelsTest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import stickman.model.GameEngine;
import stickman.model.GameEngineImpl;
import static org.junit.Assert.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SomeMethodLevelImpTest {

}
