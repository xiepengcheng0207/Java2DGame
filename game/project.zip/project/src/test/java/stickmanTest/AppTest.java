package stickmanTest;

import org.junit.Before;
import stickman.App;

public class AppTest {
    private App app;

    @Before
    public void setup(){
        app = new App();

    }
}
